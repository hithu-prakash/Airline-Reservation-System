Follow the steps shown in images to initialize the database for running this project.

1st query to run: `SCHEMA.sql`

2nd query to run: `data.sql`

Again, credits to @ericpham380 for his installation guide. It's how I learnt about this way to Run SQL queries using Workbench with ease.
