# Airline-Reservation-System
This is a mini-mini project that lets you book air-tickets, based on Java and MySQL (using JDBC) connector.
I've used Java Swing and awt for this project.

A shoutout to @ericpham380, whose database and schema I adapted.
He has an incredibly large database there and a state-of-the-art GUI, in case you're looking for a bigger project.

Those interested in implementing this software, please read Installation.

Requirements: 
MySQL Sever 5.5+
MySQL Workbench 6.3
JDK 1.7+
