This folder here contains the image used as backgroud ( may be subject to copyright ).

In order to use this image in your project, place it anywhere in your system and give it's path to

   `setContentPane(new JLabel(new ImageIcon("C:\\Users\\User\\Desktop\\JavaMini\\Data\\LoginImage.jpg")));`

this line in all of the files (eg. line 44 in Login.java ). 

This folder also contains the database initializations files that you must Run using MySQL Workbench on your database.
BEWARE, it will delete the database named `airline` if one exists on your MySQL server.
If you need guidance for Running these queries, check https://github.com/dehnuwalaHusain/Airline-Reservation-System/installation
