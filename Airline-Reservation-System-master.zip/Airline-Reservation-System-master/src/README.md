This folder contains the souce code to the entire project.

POJO files are object classes that would serve the purpose of making the database 
available on file system ( if asked to be maintained sometime in future ).

The source code is properly documented, where required, at least.

Files such as ConfirmBooking.java contain proper business logic, which is still undocumented.
I shall update it in a few days for better understanding.
